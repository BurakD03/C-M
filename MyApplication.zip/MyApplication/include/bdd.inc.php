<?php
    $host='localhost';
    $bdd='my_db';
    $user='root';
    $pass='14160611';
try {
    	$conn = new PDO("mysql:host=$host;dbname=$", $username, $password);
    	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
catch(PDOException $e)
    {
    	die("OOPs something went wrong");
    }
 
?>

